package com.example.formBuilder.service;

import com.example.formBuilder.constants.AppConstants;
import com.example.formBuilder.dto.FormFieldResponseDto;
import com.example.formBuilder.dto.FormVersionDto;
import com.example.formBuilder.dto.UpdateFieldRequest;
import com.example.formBuilder.entity.Form;
import com.example.formBuilder.entity.FormField;
import com.example.formBuilder.entity.FormVersion;
import com.example.formBuilder.enums.FormStatus;
import com.example.formBuilder.exception.ResourceNotFoundException;
import com.example.formBuilder.exception.ValidationException;
import com.example.formBuilder.repository.FormFieldRepository;
import com.example.formBuilder.repository.FormRepository;
import com.example.formBuilder.repository.FormVersionRepository;
import com.example.formBuilder.entity.User;
import com.example.formBuilder.repository.UserRepository;
import com.example.formBuilder.security.SessionUtil;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class FormVersionService {

    private final FormVersionRepository versionRepository;
    private final FormRepository formRepository;
    private final FormFieldRepository fieldRepository;
    private final JdbcTemplate jdbcTemplate;
    private final SchemaManager schemaManager;
    private final UserRepository userRepository;

    private User getCurrentUser() {
        String username = SessionUtil.getCurrentUsername();
        if (username == null) throw new ValidationException("Unauthorized");
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new ValidationException("User not found"));
    }

    private Form checkFormOwnership(UUID formId) {
        Form form = formRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Form " + formId + " not found"));
        User user = getCurrentUser();
        if (form.getUser() != null && !form.getUser().getId().equals(user.getId())) {
            throw new ValidationException("Access denied: You do not own this form");
        }
        return form;
    }


    /**
     * Returns all versions for a form, ordered ascending (oldest first).
     */
    public List<FormVersionDto> getVersions(UUID formId) {
        checkFormOwnership(formId);
        return versionRepository.findByForm_IdOrderByVersionNumberAsc(formId)
                .stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    /**
     * Returns a specific version with full field list.
     */
    public FormVersionDto getVersion(UUID formId, UUID versionId) {
        checkFormOwnership(formId);
        FormVersion version = versionRepository.findById(versionId)
                .orElseThrow(() -> new ResourceNotFoundException("Version " + versionId + " not found"));
        if (!version.getForm().getId().equals(formId)) {
            throw new ValidationException("Version does not belong to the specified form");
        }
        return toDtoWithFields(version);
    }

    /**
     * Creates a new version by cloning the latest existing version.
     * If no version exists yet, seeds version 1 from the form's current fields/rules.
     */
    @Transactional
    public FormVersionDto createVersion(UUID formId) {
        Form form = checkFormOwnership(formId);
        String username = SessionUtil.getCurrentUsername();

        FormVersion source = resolveSourceVersion(formId);
        int nextNumber = versionRepository.findMaxVersionNumber(formId) + 1;

        // Requirement: set previous version's isLatest = false, isActive = false
        versionRepository.unsetLatestForForm(formId);
        versionRepository.deactivateAllForForm(formId);

        FormVersion newVersion = FormVersion.builder()
                .form(form)
                .versionNumber(nextNumber)
                // FIXED: New version of a DRAFT form should be INACTIVE.
                // It only becomes active when you click Publish.
                .isActive(form.getStatus() == com.example.formBuilder.enums.FormStatus.PUBLISHED)
                .isLatest(true)
                .rules(source != null && source.getRules() != null ? source.getRules() : (form.getRules() != null ? form.getRules() : "[]"))
                .createdBy(username)
                .createdAt(LocalDateTime.now())
                .build();
        newVersion = versionRepository.save(newVersion);

        // Clone fields from source version (or from the form's legacy fields)
        List<FormField> sourceFields = resolveFieldsToClone(formId, source);
        List<FormField> clonedFields = cloneFields(sourceFields, newVersion);
        // FIXED: Ensure no duplicates before saving
        validateUniqueFields(clonedFields);
        fieldRepository.saveAll(clonedFields);

        // Ensure schema is updated for this new active version
        ensureSchemaForVersion(form, newVersion);
        
        // FIXED: Removed form.setStatus(PUBLISHED) from here. 
        // Versioning and Publishing are now decoupled.
        // ensureSchemaForVersion(form, newVersion); // Still needed to ensure schema if form is already published
        
        log.info("Created and activated version {} for form {}", nextNumber, formId);
        return toDtoWithFields(newVersion);
    }

    /**
     * Seeds the very first version (v1) for a new form.
     */
    @Transactional
    public FormVersionDto createInitialVersion(UUID formId, List<FormField> fields, String rules) {
        Form form = getFormOrThrow(formId);
        String username = SessionUtil.getCurrentUsername();

        FormVersion v1 = FormVersion.builder()
                .form(form)
                .versionNumber(1)
                .isActive(true)
                .isLatest(true)
                .rules(rules != null ? rules : "[]")
                .createdBy(username)
                .createdAt(LocalDateTime.now())
                .build();
        v1 = versionRepository.save(v1);

        for (FormField f : fields) {
            f.setFormVersion(v1);
        }
        // FIXED: Final check for unique field names before publication
        validateUniqueFields(fields);
        fieldRepository.saveAll(fields);

        form.setStatus(FormStatus.PUBLISHED);
        formRepository.save(form);
        
        ensureSchemaForVersion(form, v1);
 
        return toDtoWithFields(v1);
    }

    /**
     * Activates a version, deactivating all others. Also discards draft submissions
     * written against any previously active version.
     */
    @Transactional
    public FormVersionDto activateVersion(UUID formId, UUID versionId) {
        Form form = checkFormOwnership(formId);

        FormVersion toActivate = versionRepository.findById(versionId)
                .orElseThrow(() -> new ResourceNotFoundException("Version " + versionId + " not found"));
        if (!toActivate.getForm().getId().equals(formId)) {
            throw new ValidationException("Version does not belong to the specified form");
        }

        log.info("Manually activating version {} for form {}", toActivate.getVersionNumber(), form.getId());
        
        // Rule 8: On every activation, old drafts MUST be deleted.
        // FIXED: Only discard drafts if the form is already PUBLISHED.
        // For new draft forms, no submission table exists yet, so this would fail.
        if (form.getStatus() == FormStatus.PUBLISHED) {
            discardDraftsForForm(form);
        } else {
            log.info("Skipping draft cleanup for form {}: currently in {} state", form.getId(), form.getStatus());
        }

        versionRepository.deactivateAllForForm(form.getId());
        toActivate.setIsActive(true);
        versionRepository.saveAndFlush(toActivate);

        // FIXED: Set status to PUBLISHED BEFORE schema sync so guard allows it
        form.setStatus(FormStatus.PUBLISHED);
        formRepository.saveAndFlush(form);
        
        // Ensure DB schema reflects this version's fields
        log.info("Activating version {} for form {}. Status is {}. Pre-sync schema check.", 
                toActivate.getVersionNumber(), form.getId(), form.getStatus());
        ensureSchemaForVersion(form, toActivate);

        log.info("Successfully activated version {} for form {}", toActivate.getVersionNumber(), form.getId());
        return toDtoWithFields(toActivate);
    }


    @Transactional
    public FormVersionDto updateVersionFields(UUID versionId, List<UpdateFieldRequest> incoming) {
        FormVersion current = versionRepository.findById(versionId)
                .orElseThrow(() -> new ResourceNotFoundException("Version not found"));
        
        // Rule 5: Once a field is created with a specific type, its type MUST NEVER change.
        validateFieldConsistency(current.getId(), incoming);
        
        // FIXED: Ensure all field names are unique within the version to prevent bad SQL grammar
        validateUniqueFieldNames(incoming);

        Form form = checkFormOwnership(current.getForm().getId()); // Use ownership check

        // FIXED: IF form is DRAFT, update the existing version in-place
        if (form.getStatus() == FormStatus.DRAFT) {
            log.info("Draft Edit: Updating existing draft version v{} for fields. Replacing all fields.", current.getVersionNumber()); // FIXED: Added log
            fieldRepository.deleteByFormVersionId(current.getId());
            fieldRepository.flush(); // FIXED: Force flush to ensure old fields are deleted before saveAll
            
            List<FormField> newFields = new ArrayList<>();
            Map<String, FormField> keyToField = new HashMap<>();
            int order = 1;

            // 1st Pass: Build fields
            for (UpdateFieldRequest req : incoming) {
                FormField field = buildFormField(req);
                field.setFormVersion(current);
                field.setForm(form);
                field.setDisplayOrder(order++);
                keyToField.put(field.getFieldKey(), field);
                newFields.add(field);
            }

            // 2nd Pass: Wire parents
            for (int i = 0; i < incoming.size(); i++) {
                UpdateFieldRequest req = incoming.get(i);
                FormField field = newFields.get(i);
                if (req.getParentId() != null && !req.getParentId().isBlank()) {
                    field.setParent(keyToField.get(req.getParentId()));
                }
            }

            fieldRepository.saveAll(newFields);
            log.info("Successfully saved {} new fields for draft version v{}", newFields.size(), current.getVersionNumber());
            return toDtoWithFields(current);
        }

        // REUSE LOGIC: If the LATEST version for this form is very recent (< 10s) 
        // and was created by the same user, UPDATE it instead of creating another version.
        FormVersion latest = versionRepository.findFirstByForm_IdOrderByVersionNumberDesc(current.getForm().getId()).orElse(current);
        if (isRecent(latest)) {
            log.info("Edit session: Reusing very recent version v{} for fields update", latest.getVersionNumber());
            fieldRepository.deleteByFormVersionId(latest.getId());
            
            List<FormField> newFields = new ArrayList<>();
            Map<String, FormField> keyToField = new HashMap<>();
            int order = 1;

            // 1st Pass
            for (UpdateFieldRequest req : incoming) {
                FormField field = buildFormField(req);
                field.setFormVersion(latest);
                field.setForm(form);
                field.setDisplayOrder(order++);
                keyToField.put(field.getFieldKey(), field);
                newFields.add(field);
            }

            // 2nd Pass
            for (int i = 0; i < incoming.size(); i++) {
                UpdateFieldRequest req = incoming.get(i);
                FormField field = newFields.get(i);
                if (req.getParentId() != null && !req.getParentId().isBlank()) {
                    field.setParent(keyToField.get(req.getParentId()));
                }
            }

            fieldRepository.saveAll(newFields);
            ensureSchemaForVersion(form, latest);
            return toDtoWithFields(latest);
        }

        int nextNumber = versionRepository.findMaxVersionNumber(current.getForm().getId()) + 1;
        
        // Rule 4.2: When a NEW version becomes ACTIVE, ALL drafts from the previous version MUST be deleted.
        discardDraftsForVersion(form, current.getId());

        versionRepository.unsetLatestForForm(current.getForm().getId());
        versionRepository.deactivateAllForForm(current.getForm().getId());

        FormVersion newVersion = FormVersion.builder()
                .form(form)
                .versionNumber(nextNumber)
                .isActive(true) // Rule 2: New version automatically becomes ACTIVE.
                .isLatest(true)
                .rules(current.getRules() != null ? current.getRules() : "[]")
                .createdBy(SessionUtil.getCurrentUsername())
                .createdAt(LocalDateTime.now())
                .build();
        newVersion = versionRepository.save(newVersion);

        // Save incoming fields to the NEW version
        List<FormField> newFields = new ArrayList<>();
        Map<String, FormField> keyToField = new HashMap<>();
        int order = 1;
        
        // 1st Pass: Build fields
        for (UpdateFieldRequest req : incoming) {
            FormField field = buildFormField(req);
            field.setFormVersion(newVersion);
            field.setForm(form);
            field.setDisplayOrder(order++);
            keyToField.put(field.getFieldKey(), field);
            newFields.add(field);
        }

        // 2nd Pass: Wire parents
        for (int i = 0; i < incoming.size(); i++) {
            UpdateFieldRequest req = incoming.get(i);
            FormField field = newFields.get(i);
            if (req.getParentId() != null && !req.getParentId().isBlank()) {
                field.setParent(keyToField.get(req.getParentId()));
            }
        }

        fieldRepository.saveAll(newFields);

        // Sync schema
        ensureSchemaForVersion(form, newVersion);
        
        // FIXED: Removed form.setStatus(PUBLISHED). Save does not trigger publish.

        log.info("Edit session: Created new active version {} for form {}", nextNumber, current.getForm().getId());
        return toDtoWithFields(newVersion);
    }

    @Transactional
    public FormVersionDto updateVersionRules(UUID versionId, String rulesJson) {
        FormVersion current = versionRepository.findById(versionId)
                .orElseThrow(() -> new ResourceNotFoundException("Version not found"));

        Form form = checkFormOwnership(current.getForm().getId()); // Use ownership check

        // FIXED: IF form is DRAFT, update the existing version in-place
        if (form.getStatus() == FormStatus.DRAFT) {
            log.info("Draft Rules Update: Updating existing draft version v{} rules", current.getVersionNumber());
            current.setRules(rulesJson != null ? rulesJson : "[]");
            current.setUpdatedAt(LocalDateTime.now());
            versionRepository.save(current);
            // FIXED: Do NOT call ensureSchemaForVersion or change form status
            return toDtoWithFields(current);
        }

        // REUSE LOGIC: Update existing if very recent
        FormVersion latest = versionRepository.findFirstByForm_IdOrderByVersionNumberDesc(current.getForm().getId()).orElse(current);
        if (isRecent(latest)) {
            log.info("Rules update: Reusing very recent version v{}", latest.getVersionNumber());
            latest.setRules(rulesJson != null ? rulesJson : "[]");
            latest.setUpdatedAt(LocalDateTime.now());
            latest = versionRepository.save(latest);
            return toDtoWithFields(latest);
        }

        int nextNumber = versionRepository.findMaxVersionNumber(current.getForm().getId()) + 1;
        
        // Rule 4.2: Discard drafts when a NEW version becomes active.
        discardDraftsForVersion(form, current.getId());

        versionRepository.unsetLatestForForm(current.getForm().getId());
        versionRepository.deactivateAllForForm(current.getForm().getId());

        FormVersion newVersion = FormVersion.builder()
                .form(form)
                .versionNumber(nextNumber)
                .isActive(true)
                .isLatest(true)
                .rules(rulesJson != null ? rulesJson : "[]")
                .createdBy(SessionUtil.getCurrentUsername())
                .createdAt(LocalDateTime.now())
                .build();
        newVersion = versionRepository.save(newVersion);

        // Clone fields from 'current' to the NEW version
        List<FormField> currentFields = fieldRepository.findByFormVersion_IdOrderByDisplayOrderAscIdAsc(versionId);

        List<FormField> clonedFields = cloneFields(currentFields, newVersion);
        fieldRepository.saveAll(clonedFields);
        
        // FIXED: Removed form.setStatus(PUBLISHED). Rules update does not trigger publish.
 
        log.info("Rules update: Created new active version {} for form {}", nextNumber, current.getForm().getId());
        return toDtoWithFields(newVersion);
    }

    private void validateUniqueFields(List<FormField> fields) {
        if (fields == null) return;
        Set<String> seen = new java.util.HashSet<>();
        for (FormField f : fields) {
            if (isDisplayOnly(f.getFieldType())) continue;
            String key = f.getFieldKey();
            if (key == null || key.isBlank()) continue;
            String lower = key.toLowerCase();
            if (seen.contains(lower)) {
                log.error("CRITICAL: Duplicate field key '{}' detected for Version ID {}", key, f.getFormVersion() != null ? f.getFormVersion().getId() : "NULL");
                throw new ValidationException("Architectural error: Duplicate field key '" + key + "' found. Please ensure all form labels result in unique keys.");
            }
            seen.add(lower);
        }
    }

    private void validateUniqueFieldNames(List<UpdateFieldRequest> incoming) {
        if (incoming == null) return;
        java.util.Set<String> seen = new java.util.HashSet<>();
        for (com.example.formBuilder.dto.UpdateFieldRequest req : incoming) {
            String name = req.getName();
            String key = req.getFieldKey();
            if (key == null || key.isBlank()) {
                key = com.example.formBuilder.constants.AppConstants.sanitizeKey(name);
            }
            // Skip validation for display-only types since they have no DB column
            if (isDisplayOnly(req.getType())) continue;
             
            if (key == null || key.isBlank()) continue;
            
            // NEW: Validate the key for SQL safety (no spaces, starts with letter)
            schemaManager.validateColumnName(key);
            
            if (seen.contains(key)) {
                log.error("Duplicate field key found: {}", key);
                throw new ValidationException("Two fields have the same name or very similar labels. Please ensure every field has a unique name.");
            }
            seen.add(key);
        }
    }

    private void discardDraftsForVersion(Form form, UUID versionId) {
        String tableName = form.getTableName();
        if (tableName == null) return;

        // FIXED: Check if table even exists before trying to UPDATE it. 
        // For DRAFT forms, the table is only created upon publication.
        if (!tableExists(tableName)) return;

        try {
            String sql = "UPDATE " + tableName + " SET is_deleted = true WHERE form_version_id = ?::uuid AND is_draft = true";
            int count = jdbcTemplate.update(sql, versionId.toString());
            if (count > 0) log.info("Discarded {} drafts for version {} of form {}", count, versionId, form.getId());
        } catch (Exception e) { log.warn("Could not discard drafts for version {}: {}", versionId, e.getMessage()); }
    }

    private void discardDraftsForForm(Form form) {
        String tableName = form.getTableName();
        if (tableName == null) return;

        // FIXED: Check if table even exists before trying to UPDATE it.
        // Fails previously for edited DRAFT forms where table wasn't created yet.
        if (!tableExists(tableName)) return;

        try {
            String sql = "UPDATE " + tableName + " SET is_deleted = true WHERE is_draft = true";
            int count = jdbcTemplate.update(sql);
            if (count > 0) log.info("Discarded all {} drafts for form {}", count, form.getId());
        } catch (Exception e) { log.warn("Could not discard drafts for form {}: {}", form.getId(), e.getMessage()); }
    }

    private void validateFieldConsistency(UUID sourceVersionId, List<UpdateFieldRequest> incoming) {
        List<FormField> sourceFields = fieldRepository.findByFormVersion_IdOrderByDisplayOrderAscIdAsc(sourceVersionId);

        // Map by technical fieldKey (stable) instead of fieldName (label)
        Map<String, String> keyToType = sourceFields.stream()
                .filter(f -> f.getFieldKey() != null)
                .collect(Collectors.toMap(FormField::getFieldKey, FormField::getFieldType, (a, b) -> a));
        
        for (UpdateFieldRequest req : incoming) {
            String key = req.getFieldKey();
            if (key == null || key.isBlank()) {
                key = AppConstants.sanitizeKey(req.getName());
            }

            String oldType = keyToType.get(key);
            if (oldType != null && !oldType.equals(req.getType())) {
                throw new ValidationException("Field type consistency rule: Field key '" + key + 
                        "' (Label: '" + req.getName() + "') cannot change from " + oldType + " to " + req.getType());
            }
        }
    }

    private void applyFieldUpdates(FormField field, UpdateFieldRequest req) {
        field.setFieldName(req.getName());
        String key = req.getFieldKey();
        if (key == null || key.isBlank()) {
            key = AppConstants.sanitizeKey(req.getName());
        }
        field.setFieldKey(key);
        field.setFieldType(req.getType());
        field.setRequired(req.getRequired());
        field.setMinLength(req.getMinLength());
        field.setMaxLength(req.getMaxLength());
        field.setMin(req.getMin());
        field.setMax(req.getMax());
        field.setPattern(req.getPattern());
        field.setDefaultValue(req.getDefaultValue());
        field.setPlaceholder(req.getPlaceholder());
        field.setHelperText(req.getHelperText());
        field.setOptions(req.getOptions());
        field.setSourceTable(req.getSourceTable());
        field.setSourceColumn(req.getSourceColumn());
        field.setAfterTime(req.getAfterTime());
        field.setBeforeTime(req.getBeforeTime());
        field.setBeforeDatetime(req.getBeforeDatetime());
        field.setAfterDatetime(req.getAfterDatetime());
        field.setIsReadOnly(Boolean.TRUE.equals(req.getIsReadOnly()));
        field.setIsMultiSelect(Boolean.TRUE.equals(req.getIsMultiSelect()));
        field.setIsUnique(Boolean.TRUE.equals(req.getIsUnique()));
        field.setIsCalculated(Boolean.TRUE.equals(req.getIsCalculated()));
        field.setCalculationFormula(req.getCalculationFormula());
    }


    private FormField buildFormField(UpdateFieldRequest req) {
        FormField field = new FormField();
        applyFieldUpdates(field, req);
        return field;
    }

    /**
     * Requirement: Always create a new version on edit.
     * To prevent the 'triple version' issue caused by multiple rapid frontend requests (e.g. React StrictMode),
     * we reuse a version if it was created within the last 10 seconds for the same form and user.
     */
    @Transactional
    public FormVersionDto getOrCreateDraft(UUID formId) {
        checkFormOwnership(formId);
        Optional<FormVersion> latestOpt = versionRepository.findFirstByForm_IdOrderByVersionNumberDesc(formId);

        if (latestOpt.isPresent()) {
            // Return the latest version. Branching (creating a new version) will only happen 
            // when the user actually saves their changes via updateVersionFields.
            return toDtoWithFields(latestOpt.get());
        }
        
        return createVersion(formId);
    }

    private boolean isRecent(FormVersion v) {
        if (v == null || v.getCreatedAt() == null) return false;
        LocalDateTime now = LocalDateTime.now();
        return v.getCreatedAt().isAfter(now.minusSeconds(10)) &&
               Objects.equals(v.getCreatedBy(), SessionUtil.getCurrentUsername());
    }

    /**
     * Startup migration: for every published/existing form that has no version records yet,
     * auto-create version 1 (active) from the form's current legacy fields/rules.
     * Runs idempotently — checks before inserting.
     */
    @Transactional
    public void migrateExistingForms() {
        // Step 1: Populate field_key for all fields that don't have one
        List<FormField> fieldsToMigrate = fieldRepository.findAll();
        for (FormField f : fieldsToMigrate) {
            if (f.getFieldKey() == null || f.getFieldKey().isBlank()) {
                f.setFieldKey(AppConstants.sanitizeKey(f.getFieldName()));
            }
        }
        fieldRepository.saveAll(fieldsToMigrate);

        // Step 2: Existing logic for version migration
        List<Form> allForms = formRepository.findAll();
        for (Form form : allForms) {
            if (!versionRepository.existsByForm_Id(form.getId())) {
                log.info("Migrating form {} to versioning model", form.getId());
                autoCreateVersionForForm(form);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // INTERNAL HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    private void autoCreateVersionForForm(Form form) {
        FormVersion v1 = FormVersion.builder()
                .form(form)
                .versionNumber(1)
                .isActive(form.getStatus() == FormStatus.PUBLISHED)
                .isLatest(true) // Migrated first version is the latest
                .rules(form.getRules() != null ? form.getRules() : "[]")
                .createdBy("system-migration")
                .createdAt(form.getCreatedAt() != null ? form.getCreatedAt() : LocalDateTime.now())
                .build();
        v1 = versionRepository.save(v1);

        // Link existing fields to this version
        List<FormField> legacyFields = fieldRepository.findByForm_IdOrderByDisplayOrderAscIdAsc(form.getId());

        int order = 1;
        for (FormField f : legacyFields) {
            f.setFormVersion(v1);
            f.setDisplayOrder(order++);
        }
        fieldRepository.saveAll(legacyFields);
    }

    private FormVersion resolveSourceVersion(UUID formId) {
        // prefer active version; fall back to the highest numbered version
        return versionRepository.findByForm_IdAndIsActiveTrue(formId)
                .or(() -> versionRepository.findByForm_IdOrderByVersionNumberAsc(formId)
                        .stream().reduce((a, b) -> b))
                .orElse(null);
    }

    private List<FormField> resolveFieldsToClone(UUID formId, FormVersion source) {
        if (source == null) {
            // FIXED: seed from initial/legacy form fields (where version_id is null)
            // findByFormId was previously returning duplicates (v1 fields + null fields)
            return fieldRepository.findByForm_IdAndFormVersionIsNullOrderByDisplayOrderAscIdAsc(formId);
        }
        return fieldRepository.findByFormVersion_IdOrderByDisplayOrderAscIdAsc(source.getId());
    }

    private List<FormField> cloneFields(List<FormField> source, FormVersion targetVersion) {
        Map<String, FormField> keyToClone = new HashMap<>();
        List<FormField> clones = new ArrayList<>();
        int order = 1;

        // 1. Create clones
        for (FormField f : source) {
            FormField clone = new FormField();
            clone.setFieldName(f.getFieldName());
            clone.setFieldKey(f.getFieldKey());
            clone.setFieldType(f.getFieldType());
            clone.setRequired(f.getRequired());
            clone.setMinLength(f.getMinLength());
            clone.setMaxLength(f.getMaxLength());
            clone.setMin(f.getMin());
            clone.setMax(f.getMax());
            clone.setPattern(f.getPattern());
            clone.setBeforeDate(f.getBeforeDate());
            clone.setAfterDate(f.getAfterDate());
            clone.setAfterTime(f.getAfterTime());
            clone.setBeforeTime(f.getBeforeTime());
            clone.setMaxFileSize(f.getMaxFileSize());
            clone.setAllowedFileTypes(f.getAllowedFileTypes());
            clone.setOptions(f.getOptions() != null ? new ArrayList<>(f.getOptions()) : null);
            clone.setSourceTable(f.getSourceTable());
            clone.setSourceColumn(f.getSourceColumn());
            clone.setDefaultValue(f.getDefaultValue());
            clone.setPlaceholder(f.getPlaceholder());
            clone.setHelperText(f.getHelperText());
            clone.setIsReadOnly(f.getIsReadOnly());
            clone.setIsMultiSelect(f.getIsMultiSelect());
            clone.setIsUnique(f.getIsUnique());
            clone.setIsCalculated(f.getIsCalculated());
            clone.setCalculationFormula(f.getCalculationFormula());
            clone.setIsDeleted(false);

            clone.setForm(f.getForm());
            clone.setFormVersion(targetVersion);
            clone.setDisplayOrder(f.getDisplayOrder() != null ? f.getDisplayOrder() : order++);
            
            keyToClone.put(clone.getFieldKey(), clone);
            clones.add(clone);
        }

        // 2. Re-wire parents within the same version
        for (int i = 0; i < source.size(); i++) {
            FormField original = source.get(i);
            FormField clone = clones.get(i);
            if (original.getParent() != null) {
                String parentKey = original.getParent().getFieldKey();
                clone.setParent(keyToClone.get(parentKey));
            }
        }

        return clones;
    }

    private boolean tableExists(String tableName) {
        if (tableName == null) return false;
        try {
            // FIXED: Using to_regclass is safer and faster in Postgres
            String sql = "SELECT to_regclass(?) IS NOT NULL";
            return Boolean.TRUE.equals(jdbcTemplate.queryForObject(sql, Boolean.class, tableName));
        } catch (Exception e) {
            log.warn("Table existence check failed for {}: {}", tableName, e.getMessage());
            return false;
        }
    }

    private void ensureSchemaForVersion(Form form, FormVersion version) {
        // FIXED: Do NOT perform schema operations for DRAFT forms. table is created only on publish.
        if (form.getStatus() != FormStatus.PUBLISHED) {
            log.info("Skipping schema sync: form {} is in {} state", form.getId(), form.getStatus()); // FIXED: Changed to info for visibility
            return;
        }

        String tableName = form.getTableName();
        log.info("Ensuring schema for form {} (table: {}) using version {}", form.getId(), tableName, version.getVersionNumber());
        
        if (tableName == null) {
            log.warn("Cannot ensure schema: tableName is null for form {}", form.getId());
            return;
        }
        
        List<FormField> fields = fieldRepository.findByFormVersion_IdOrderByDisplayOrderAscIdAsc(version.getId());

        log.info("Found {} fields for version {} of form {}", fields.size(), version.getVersionNumber(), form.getId());
        
        // FIXED: Fail early if there are duplicates to prevent Bad SQL Grammar
        validateUniqueFields(fields);
        
        if (fields.isEmpty()) {
            log.warn("Warning: version {} has NO fields. Table creation might yield an empty form.", version.getVersionNumber());
        }

        // FIXED: Use helper method
        if (!tableExists(tableName)) {
            // Table doesn't exist — create it
            schemaManager.createDynamicTable(tableName, fields);
            // Add common columns if not present
            addMissingCommonColumns(tableName);
            return;
        }

        // Table exists — add any missing columns (schema evolution)
        addMissingCommonColumns(tableName);
        for (FormField field : fields) {
            if (isDisplayOnly(field.getFieldType())) continue;
            try {
                String colCheck = "SELECT COUNT(*) FROM information_schema.columns " +
                        "WHERE table_name = ? AND column_name = ?";
                Integer colCount = jdbcTemplate.queryForObject(colCheck, Integer.class,
                        tableName, field.getFieldKey());
                if (colCount == null || colCount == 0) {
                    schemaManager.addColumn(tableName, field);
                }
            } catch (Exception ex) {
                log.warn("Could not check/add column {} to {}: {}", field.getFieldKey(), tableName, ex.getMessage());
            }
        }

        // ── Drift verification after schema sync ─────────────────────────────────
        // All missing columns should have been added above. If drift still exists,
        // something went wrong — block the publish to prevent broken submissions.
        List<String> remainingDrift = schemaManager.detectDrift(tableName, fields);
        if (!remainingDrift.isEmpty()) {
            throw new ValidationException(
                "Publish blocked: schema drift detected after migration attempt. " +
                "Missing columns in table '" + tableName + "': " +
                String.join(", ", remainingDrift) + ". Manual database intervention required."
            );
        }
    }


    private void addMissingCommonColumns(String tableName) {
        try {
            jdbcTemplate.execute("ALTER TABLE " + tableName + " ADD COLUMN IF NOT EXISTS form_version_id UUID");
            jdbcTemplate.execute("ALTER TABLE " + tableName + " ADD COLUMN IF NOT EXISTS is_draft BOOLEAN DEFAULT FALSE NOT NULL");
            jdbcTemplate.execute("ALTER TABLE " + tableName + " ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN DEFAULT FALSE NOT NULL");
            jdbcTemplate.execute("ALTER TABLE " + tableName + " ADD COLUMN IF NOT EXISTS submitted_by VARCHAR(100)");
            jdbcTemplate.execute("ALTER TABLE " + tableName + " ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL");
        } catch (Exception e) {
            log.warn("Could not add common columns to {}: {}", tableName, e.getMessage());
        }
    }

    private boolean isDisplayOnly(String type) {
        return type != null && (type.equals("page_break") || type.equals("heading")
                || type.equals("paragraph") || type.equals("divider"));
    }

    private Form getFormOrThrow(UUID formId) {
        return formRepository.findById(formId)
                .orElseThrow(() -> new ResourceNotFoundException("Form " + formId + " not found"));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DTO MAPPING
    // ─────────────────────────────────────────────────────────────────────────

    private FormVersionDto toDto(FormVersion v) {
        return FormVersionDto.builder()
                .id(v.getId())
                .formId(v.getForm().getId())
                .versionNumber(v.getVersionNumber())
                .isActive(v.getIsActive())
                .isLatest(v.getIsLatest())
                .rules(v.getRules())
                .createdBy(v.getCreatedBy())
                .createdAt(v.getCreatedAt())
                .updatedAt(v.getUpdatedAt())
                .build();
    }

    private FormVersionDto toDtoWithFields(FormVersion version) {
        List<FormField> fields = fieldRepository.findByFormVersion_IdOrderByDisplayOrderAscIdAsc(version.getId());

        List<FormFieldResponseDto> fieldDtos = fields.stream()
                .filter(f -> !Boolean.TRUE.equals(f.getIsDeleted()))
                .map(f -> FormFieldResponseDto.builder()
                        .id(f.getId())
                        .fieldName(f.getFieldName())
                        .fieldKey(f.getFieldKey())
                        .fieldType(f.getFieldType())
                        .required(f.getRequired())
                        .minLength(f.getMinLength())
                        .maxLength(f.getMaxLength())
                        .min(f.getMin())
                        .max(f.getMax())
                        .pattern(f.getPattern())
                        .beforeDate(f.getBeforeDate())
                        .afterDate(f.getAfterDate())
                        .afterTime(f.getAfterTime())
                        .beforeTime(f.getBeforeTime())
                        .beforeDatetime(f.getBeforeDatetime())
                        .afterDatetime(f.getAfterDatetime())
                        .options(f.getOptions() != null ? new ArrayList<>(f.getOptions()) : null)
                        .sourceTable(f.getSourceTable())
                        .sourceColumn(f.getSourceColumn())
                        .defaultValue(f.getDefaultValue())
                        .placeholder(f.getPlaceholder())
                        .helperText(f.getHelperText())
                        .maxFileSize(f.getMaxFileSize())
                        .allowedFileTypes(f.getAllowedFileTypes())
                        .isReadOnly(f.getIsReadOnly())
                        .isMultiSelect(f.getIsMultiSelect())
                        .isUnique(f.getIsUnique())
                        .isCalculated(f.getIsCalculated())
                        .calculationFormula(f.getCalculationFormula())
                        .parentId(f.getParent() != null ? f.getParent().getId().toString() : null)
                        .build())

                .collect(Collectors.toList());

        return FormVersionDto.builder()
                .id(version.getId())
                .formId(version.getForm().getId())
                .versionNumber(version.getVersionNumber())
                .isActive(version.getIsActive())
                .createdBy(version.getCreatedBy())
                .createdAt(version.getCreatedAt())
                .rules(version.getRules())
                .fields(fieldDtos)
                .build();
    }
}
