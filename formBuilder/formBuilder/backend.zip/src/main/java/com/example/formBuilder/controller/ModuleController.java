package com.example.formBuilder.controller;

import com.example.formBuilder.dto.ApiResponse;
import com.example.formBuilder.entity.Module;
import com.example.formBuilder.service.ModuleService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class ModuleController {

    private final ModuleService moduleService;

    @PostMapping("/modules")
    @PreAuthorize("hasRole('SYSTEM_ADMIN')")
    public ResponseEntity<ApiResponse<Module>> createModule(@RequestBody Module module) {
        return ResponseEntity.ok(ApiResponse.success(moduleService.createModule(module)));
    }

    @PutMapping("/modules/{id}")
    @PreAuthorize("hasRole('SYSTEM_ADMIN')")
    public ResponseEntity<ApiResponse<Module>> updateModule(@PathVariable UUID id, @RequestBody Module module) {
        return ResponseEntity.ok(ApiResponse.success(moduleService.updateModule(id, module)));
    }

    @GetMapping("/modules")
    @PreAuthorize("hasRole('SYSTEM_ADMIN')")
    public ResponseEntity<ApiResponse<List<Module>>> getAllModules() {
        return ResponseEntity.ok(ApiResponse.success(moduleService.getAllModules()));
    }

    @GetMapping("/menu")
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> getUserMenu() {
        return ResponseEntity.ok(ApiResponse.success(moduleService.getUserMenu()));
    }

    @PostMapping("/modules/seed")
    @PreAuthorize("hasRole('SYSTEM_ADMIN')")
    public ResponseEntity<ApiResponse<String>> seedModules() {
        moduleService.seedModules();
        return ResponseEntity.ok(ApiResponse.success("System seeded successfully"));
    }

    @DeleteMapping("/modules/{id}")
    public ResponseEntity<ApiResponse<String>> deleteModule(@PathVariable UUID id) {
        moduleService.deleteModule(id);
        return ResponseEntity.ok(ApiResponse.success("Module deleted successfully"));
    }


}
